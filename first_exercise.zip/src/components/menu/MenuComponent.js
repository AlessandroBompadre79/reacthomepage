import React, { Component } from 'react';
import Dishdetail from './components/DishdetailComponent';
import PAGES from '../../shared/constants/pages'

class MenuComponent extends Component {
    constructor(props) {
        super(props);

        this.state = {
            selectedPage: null,
            pages: PAGES
        }
        console.log('Menu component constructor invoked');
    }

    componentDidMount() {
        console.log('Menu component componentDidMount invoked');
    }

    onPageSelect(page) {
        this.setState({selectedPage: page});
    }

    renderPage(page) {
        const desc = true;
        if(page) {
            return (
                <Dishdetail page={page} desc={desc}/>
            );
        } else {
            return (
                <div></div>
            );
        }
    }

    render() {
        console.log('Menu component render invoked');
        const menu = this.state.pages.map(page => {
            return (
                <div key={page.id} className="col-12 col-md-5 m1" onClick={() => this.onPageSelect(page)}>
                    <Dishdetail page={page}/>
                </div>
            );
        });
        return (
            <div className="container">
                <div className="row">
                    {menu}
                </div>
                <div className="row">
                    {this.renderPage(this.state.selectedPage)}
                </div>
            </div>
        );
    }
}

export default MenuComponent;