import { render } from '@testing-library/react';
import React, {Component } from 'react';
import { CardImg, CardBody, CardText, Card, CardTitle, CardFooter } from 'reactstrap';

class CardOverlayComponent extends Component {
        renderDish(dish) {
            return (<Card className="col-5">
                        <CardImg src={dish.image} alt={dish.name}/>
                        <CardBody>
                            <CardTitle>
                                <h3>
                                    {dish.name}
                                </h3>
                            </CardTitle>
                            <CardText>
                                {dish.description}
                            </CardText>
                        </CardBody>
                    </Card>);
        }
        
        renderComments(comments) {
            return comments.map(comment => {
                const d = new Date(comment.date);
                const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                return (
                    <div key={comment.id} className="col-12 text-right">
                        <h5>{comment.comment}</h5>
                        <h6>
                            -- {comment.author}, {months[d.getMonth()]} {d.getDate()},{d.getFullYear()}
                        </h6>
                        <hr/>
                    </div>
                );
            });
        }

        render() {
            const menu = this.renderComments(this.props.page.comments);
            const card = this.renderDish(this.props.page);
            return (
                <div className="col-12">
                    <div className="col-12">
                        <div className="row">
                            {card}
                            <Card className="col-5">
                                <CardTitle>
                                    <h4>
                                        Comments
                                    </h4>
                                </CardTitle>
                                <CardBody>
                                    {menu}
                                </CardBody>
                            </Card>
                        </div>
                    </div>
                </div>
            );
        }
}

export default CardOverlayComponent;