import React from 'react';
import { CardImg, CardImgOverlay, Card, CardTitle } from 'reactstrap';

function CardOverlayComponent(props) {
        return (
            <Card>
                <CardImg width="100%" src={props.page.image} alt={props.page.name}/>
                <CardImgOverlay>
                    <CardTitle>
                        {props.page.name}
                    </CardTitle>
                </CardImgOverlay>
            </Card>
        );
}

export default CardOverlayComponent;