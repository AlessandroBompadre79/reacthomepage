import React, { Component } from 'react';
import CardOverlayComponent from './templates/CardOverlayComponent';
import CardBodyComponent from './templates/CardBodyComponent';

class Dishdetail  extends Component {
    render() {
        if(this.props.desc) {
          return (
            <CardBodyComponent page={this.props.page} />
          );
        }
        return (
            <CardOverlayComponent page={this.props.page} />
        );
    }
}

export default Dishdetail;